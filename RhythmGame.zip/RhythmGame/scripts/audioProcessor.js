const audioCache = new Map(); // Cache for audio files

export async function preloadAudio(audioUrl, audioContext = new (window.AudioContext || window.webkitAudioContext)()) {
    if (audioCache.has(audioUrl)) {
        console.log(`Audio loaded from cache: ${audioUrl}`);
        return audioCache.get(audioUrl);
    }

    try {
        const response = await fetch(audioUrl);
        if (!response.ok) throw new Error(`Failed to fetch audio: ${response.statusText}`);

        const arrayBuffer = await response.arrayBuffer();
        const audioBuffer = await audioContext.decodeAudioData(arrayBuffer);
        audioCache.set(audioUrl, audioBuffer);
        console.log(`Audio successfully preloaded: ${audioUrl}`);
        return audioBuffer;
    } catch (error) {
        console.error(`Error preloading audio: ${error.message}`);
        throw error;
    }
}

export async function processAudioFromURL(audioUrl) {
    const audioContext = new (window.AudioContext || window.webkitAudioContext)();
    try {
        const audioBuffer = await preloadAudio(audioUrl, audioContext);
        const tempo = await detectTempo(audioBuffer);
        const onsets = await detectOnsets(audioBuffer);

        // Generate notes based on detected onsets
        const notes = onsets.map((onset, index) => ({
            lane: index % 4, // Rotate through lanes
            time: onset, // Time from onset detection
            duration: 0 // Short notes
        }));

        console.log(`Generated ${notes.length} notes from onsets.`);
        return { notes, tempo, onsets };
    } catch (error) {
        console.error(`Error processing audio from URL: ${error.message}`);
        throw error;
    }
}


async function detectTempo(audioBuffer) {
    const offlineContext = new OfflineAudioContext(1, audioBuffer.length, audioBuffer.sampleRate);
    const source = offlineContext.createBufferSource();
    source.buffer = audioBuffer;

    const analyser = offlineContext.createAnalyser();
    analyser.fftSize = 2048;

    source.connect(analyser);
    analyser.connect(offlineContext.destination);
    source.start(0);

    const renderedBuffer = await offlineContext.startRendering();
    const channelData = renderedBuffer.getChannelData(0);

    const bpm = calculateBPM(channelData, offlineContext.sampleRate);
    console.log(`Detected tempo: ${bpm} BPM`);
    return bpm;
}

function calculateBPM(channelData, sampleRate) {
    const autocorrelation = new Float32Array(channelData.length);

    for (let lag = 0; lag < autocorrelation.length; lag++) {
        let sum = 0;
        for (let i = 0; i < channelData.length - lag; i++) {
            sum += channelData[i] * channelData[i + lag];
        }
        autocorrelation[lag] = sum;
    }

    // Find the peak in the autocorrelation
    let peakLag = 0;
    let peakValue = 0;
    for (let i = 1; i < autocorrelation.length; i++) {
        if (autocorrelation[i] > peakValue) {
            peakValue = autocorrelation[i];
            peakLag = i;
        }
    }

    const bpm = (60 * sampleRate) / peakLag;
    return Math.round(bpm);
}

async function detectOnsets(audioBuffer) {
    const offlineContext = new OfflineAudioContext(1, audioBuffer.length, audioBuffer.sampleRate);
    const source = offlineContext.createBufferSource();
    source.buffer = audioBuffer;

    const analyser = offlineContext.createAnalyser();
    analyser.fftSize = 2048;

    source.connect(analyser);
    analyser.connect(offlineContext.destination);
    source.start(0);

    const renderedBuffer = await offlineContext.startRendering();
    const channelData = renderedBuffer.getChannelData(0);

    const threshold = 0.1;
    const onsets = [];
    for (let i = 1; i < channelData.length; i++) {
        if (Math.abs(channelData[i] - channelData[i - 1]) > threshold) {
            onsets.push(i / renderedBuffer.sampleRate); // Convert index to time in seconds
        }
    }

    console.log(`Detected ${onsets.length} onsets`);
    return onsets;
}

async function generateNotesFromPitch(audioBuffer, tempo, onsets) {
    const offlineContext = new OfflineAudioContext(1, audioBuffer.length, audioBuffer.sampleRate);
    const source = offlineContext.createBufferSource();
    source.buffer = audioBuffer;

    const analyser = offlineContext.createAnalyser();
    analyser.fftSize = 2048;

    source.connect(analyser);
    analyser.connect(offlineContext.destination);
    source.start(0);

    const renderedBuffer = await offlineContext.startRendering();
    const sampleRate = offlineContext.sampleRate;

    const notes = [];
    const bufferData = renderedBuffer.getChannelData(0);

    const stepSize = 256; // Step size in samples
    let lastPitch = null;

    for (let i = 0; i < bufferData.length; i += stepSize) {
        const frame = bufferData.slice(i, i + 2048);
        const pitch = detectPitch(frame, sampleRate);

        if (pitch && (!lastPitch || Math.abs(pitch - lastPitch) > 20)) {
            notes.push({
                lane: Math.floor(Math.random() * 4), // Random lane
                time: i / sampleRate, // Time in seconds
                duration: 0 // Short notes for simplicity
            });
            lastPitch = pitch;
        }
    }

    console.log(`Generated ${notes.length} notes`);
    return notes;
}

function detectPitch(buffer, sampleRate) {
    const maxShift = Math.floor(buffer.length / 2);
    let bestOffset = -1;
    let bestCorrelation = 0;

    const mean = buffer.reduce((sum, value) => sum + value, 0) / buffer.length;
    const normalizedBuffer = buffer.map(value => value - mean);

    for (let offset = 8; offset < maxShift; offset++) {
        let correlation = 0;

        for (let i = 0; i < maxShift; i++) {
            correlation += normalizedBuffer[i] * normalizedBuffer[i + offset];
        }

        correlation = correlation / maxShift;

        if (correlation > bestCorrelation) {
            bestCorrelation = correlation;
            bestOffset = offset;
        }
    }

    if (bestCorrelation > 0.9 && bestOffset > 0) {
        const frequency = sampleRate / bestOffset;
        return frequency;
    }

    return null; // No significant pitch detected
}
